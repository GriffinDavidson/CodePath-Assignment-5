//
//  CameraViewController.swift
//  parstagram
//
//  Created by Griffin Davidson on 3/25/22.
//

import UIKit
import AlamofireImage
import Parse

class CameraViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate
{

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var postTextField: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.title = "Create New Post"

        // Do any additional setup after loading the view.
    }
    
    @IBAction func onSubmit(_ sender: Any)
    {
        let post = PFObject(className: "Posts")
        
        post["caption"] = postTextField.text
        post["owner"] = PFUser.current()!
        
        let imageData = imageView.image!.pngData()
        let file = PFFileObject(name: "image.png", data: imageData!)
        
        post["image"] = file
        
        post.saveInBackground
        { (success, failure) in
            if success
            {
                print("Posted!")
                self.dismiss(animated: true, completion: nil)
            }
            else
            {
                print("Failed to Post")
            }
        }
    }

    @IBAction func onCameraButton(_ sender: Any?)
    {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        
        let actionSheet = UIAlertController(title: "Select Media",
                                            message: "Choose to pick from Image Library or Camera",
                                            preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Choose from Library",
                                            style: .default,
                                            handler:
        { (_) in
            // Action Here
            self.present(picker, animated: true, completion: nil)
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Take Photo",
                                            style: .default,
                                            handler:
        { (_) in
            // Action Here
            
            if UIImagePickerController.isSourceTypeAvailable(.camera)
            {
                picker.sourceType = .camera
            }
            
            self.present(picker, animated: true, completion: nil)
            
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel",
                                            style: .cancel))
        
        present(actionSheet, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[.editedImage] as! UIImage
        
        let size = CGSize(width: 374, height: 374)
        let scaledImage = image.af.imageScaled(to: size)
        imageView.image = scaledImage
        
        self.dismiss(animated: true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    
    @IBAction func onCancel(_ sender: Any)
    {
        self.dismiss(animated: true)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
