//
//  PostTableViewCell.swift
//  parstagram
//
//  Created by Griffin Davidson on 3/25/22.
//

import UIKit

class PostTableViewCell: UITableViewCell
{
    
    @IBOutlet weak var postOwnerLabel: UILabel!
    @IBOutlet weak var postCaptionLabel: UILabel!
    @IBOutlet weak var postPhotoImageView: UIImageView!
    
    

    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
